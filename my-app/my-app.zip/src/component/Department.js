import React from "react";
import Home from "./Home";
function department () {
    return(
        <div>
           
            <h1>liên kết phòng ban</h1>
            
        </div>
    )
}

export default department