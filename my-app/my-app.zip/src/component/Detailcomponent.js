import React from "react";
import {useParams} from "react-router-dom"
function Detail () {
    const param  = useParams(); 
const staffId = param.staffId *1
console.log(param)
    
  
   
    return(
        <div>
            <h1>Đì têu com bao nừn</h1>
        </div>
    )
}
export default Detail