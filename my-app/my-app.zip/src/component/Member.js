import React from "react";
function Member () {
    return(
        <div>
            <h1>
            Liên kết thành viên
            </h1>
           </div>
    )
}
export default Member