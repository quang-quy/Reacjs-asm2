import React from "react";
function salary() {
    return(
        <div>
            <h1>
                liên kết lương 
            </h1>
        </div>
    )
}
export default salary